const express = require('express');
const router = express.Router();

router.post('/normal', (req, res) => {
  const saldo = Number(req.body.saldo);
  let valor = 200;

  if (saldo >= 5000) valor = 500;
  else if (saldo >= 2500) valor = 300;

  res.json({
    tipo: 'Previsão Normal',
    valor: `${valor} Kz`,
    mensagem: 'Previsão pronta para usar com base no seu saldo.'
  });
});

module.exports = router;
